package com.walmart.ticketservice;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.assertEquals;


/**
 * Unit test for simple App.
 */
public class TicketServiceTest {

    Venue venue;
    MyTicketService myTicketService;

    @Before
    public void setUp() throws Exception {

        this.venue = new Venue()
                .name("AMC")
                .seats(5,5)
                .expirationDelay(60)
                .build();

        this.myTicketService = new MyTicketService(venue);
    }

    @Test
    public void testFullFlow() throws InterruptedException{

        this.venue.setExpirationDelay(10);

        SeatHold seatHold = this.myTicketService.findAndHoldSeats(5, "abc@xyz.com");
        //Wait for sometime
        Thread.sleep( 1 * 1000);
        //Try reserving seats using SeatHoldId
        String confirmationCode = myTicketService.reserveSeats(seatHold.getSeatHoldId(), "abc@xyz.com");

        String expectedConfirmationNumber = "AMC00000001";
        assertEquals(confirmationCode, expectedConfirmationNumber);
    }

}
