package com.walmart.ticketservice;

import java.util.List;

public class SeatHold {

    private int seatHoldId;
    private String customerEmail;
    private List<Seat> seats;
    private boolean hold;
    private long delay;
    private SeatReleaseTask releaseTask;

    public Venue getVenue() {
        return venue;
    }

    private Venue venue;

    public int getSeatHoldId() {
        return seatHoldId;
    }

    public List<Seat> getSeats() {
        return seats;
    }

    public boolean isOnHold() {
        return hold;
    }

    void setHold(boolean hold){
        this.hold = hold;
    }

    SeatHold(){

    }

    SeatHold id(int id){
        this.seatHoldId=id;
        return this;
    }

    SeatHold seatsHold(List<Seat> seats){
        this.seats = seats;
        return this;
    }

    SeatHold customerEmail(String customerEmail){
        this.customerEmail = customerEmail;
        return this;
    }

    SeatHold expirationDelay(long delay) {
        this.delay = delay;
        return this;
    }
    SeatHold venue(Venue venue) {
        this.venue = venue;
        return this;
    }

    SeatHold build()
    {
        SeatHold seatHold = new SeatHold();
        seatHold.seatHoldId = generateSeatHoldId();
        seatHold.seats = this.seats;
        seatHold.customerEmail = this.customerEmail;
        seatHold.hold = true;
        seatHold.venue = venue;
        SeatReleaseTask task = new SeatReleaseTask(seatHold, this.delay);
        task.start();
        seatHold.releaseTask = task;
        return seatHold;
    }

    int generateSeatHoldId(){
        return seatHoldId;
    }

    void changeSeatStatus(SeatStatus status){
        for(Seat seat: seats){
            seat.setStatus(status);
        }
    }

    void stopReleaseTask(){
        this.releaseTask.stopTask();
    }


}
