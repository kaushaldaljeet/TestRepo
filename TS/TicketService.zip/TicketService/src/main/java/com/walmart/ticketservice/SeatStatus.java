package com.walmart.ticketservice;

public enum  SeatStatus {
    AVAILABLE, RESERVED, HOLD;
}
