package com.walmart.ticketservice;

public class MyTicketService implements TicketService {

    private Venue venue;


    public MyTicketService(Venue venue){
        this.venue = venue;
    }

    public synchronized int numSeatsAvailable(){
        return this.venue.getAvailableSeats();
    }

    public synchronized SeatHold findAndHoldSeats(int numOfSeats, String customerEmail){
        return  venue.findAndHoldSeats(numOfSeats, customerEmail);
    }

    public synchronized String reserveSeats(int seatHoldId, String customerEmail){
        return venue.reserveSeats(seatHoldId, customerEmail);
    }
}
