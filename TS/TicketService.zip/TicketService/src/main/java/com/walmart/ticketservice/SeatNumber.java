package com.walmart.ticketservice;

public class SeatNumber {

    int rowNumber;
    int colNumber;

    public SeatNumber(int rowNumber, int colNumber){
        this.rowNumber = rowNumber;
        this.colNumber = colNumber;
    }

    public int getRowNumber() {
        return rowNumber;
    }

    public void setRowNumber(int rowNumber) {
        this.rowNumber = rowNumber;
    }

    public int getColNumber() {
        return colNumber;
    }

    public void setColNumber(int colNumber) {
        this.colNumber = colNumber;
    }

    public String toString(){
        return "" + (char)('A' + getRowNumber()) + getColNumber();
    }
}
